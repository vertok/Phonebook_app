
             ############ Welcome to phonebook!  ##############


 Wenn Sie:

   -das Programm komplieren wollen, geben Sie bitte in die Konsole folgendes:
    gcc funktions.h funktions.c main.c -o phonebook `pkg-config --cflags --libs gtk+-2.0`
    und dann führen Sie die Anwendung "phonebook" aus
   
   -das haupt Bildschirm sehen wollen, die Taste "main" zu druecken

   -das Buch anschauen wollen, druecken Sie bitte die Taste "show"

   -ein Kontakt hinzufuegen wollen, druecken die Taste "add"
   (um eine Person ins Phonebook hinzufuegen, tippen Sie in das erste Feld- 
    Name, ins zweites - Vorname. Die beide fällen dürften bis max. 28 Symbolen
    groß sein. Es ist zugelassen eine " ", bzw. eine "-" einzutippen. Wenn Sie 
    aber eine Zahl oder ein anderes Symbol eingeben, wird das phonebook die Info
    veraendern( ungewoehnliche symbole werden geloescht). Wenn Sie ueberhaupt nichts 
    in ein Feld eigetippt haben, dann wird das phonebook das fehlende 
    Info durch das Wort "muster" erzetzen( das ist hilfreich, wenn man z.B. kein Vorname 
    von Person kennt oder wenn man den Kontakt auf jeden Fall im phonebook braucht, aber
    seine Nummer kennt er noch nicht). Wenn es aber gar nichts in alle Felder einkommt,
    dann wird es eine Kuze Nachricht darueber zum Bildschirm gegeben.Sie sollten nicht an 
    die Gross-/Kleinschreibung aufpassen, das Phonebook wird das selbst kontrolieren.
    In das drittes Feld tippen Sie bitte das Phonenummer ein
   (der Nummer darf bis max. 18 Symbolen gross sein und bei ihm ist es
    zugelassen die Zahlen und am Anfang es ist erlaubt ein "+" Zeichen einzutippen)
    Bei der Nummer werden auch alle ungewoehnliche Symbole geloescht)
   
   -fuer die Suche nach der Telefonnummer - die Taste "search" druecken
   (waehrend der Suche die gesuchte Nummer sollte im dritten Feld sein),
    die gesuchte Info wird gleich zum Bildschirm kommen, bzw. eine 
    Meldung, dass es kein Kontakt mit eingegebenen Nummern gefunden wurde.

   -fuer das Loeschen eines Kontaktes druecken Sie die Taste "delete"
   (Name von Person, die Sie loeschen wollen, soll im ersten Feld sein,
    Vorame von Person soll im zweiten Feld sein)
    Als Atwort gibt die Anwendung zurück entweder eine Meldung über die erfolgreiche
    Operation oder eine Meldung über Misserfolg.
   
   -um Info ueber das app zu bekommen druecken die Taste "about"

   -um das Programm zu verlassen drücken Sie bitte die Taste "quit" ein. 


                                               			   .....aaaaand have fun!
